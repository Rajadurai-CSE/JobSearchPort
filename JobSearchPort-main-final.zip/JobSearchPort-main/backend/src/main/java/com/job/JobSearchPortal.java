package com.job;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobSearchPortal {

	public static void main(String[] args) {
		SpringApplication.run(JobSearchPortal.class, args);
	}

}
