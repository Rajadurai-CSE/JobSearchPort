package com.job.enums;

public enum Role {
    ADMIN,
    EMPLOYER,
    JOB_SEEKER
}
