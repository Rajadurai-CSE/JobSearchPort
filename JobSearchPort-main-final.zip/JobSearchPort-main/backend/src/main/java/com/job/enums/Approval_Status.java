package com.job.enums;

public enum Approval_Status {
  PENDING,APPROVED,REVOKED,DENIED }
