package com.job.dto.employer;


public class CompanyDto {
    private String companyName;
    private String companyURL;
    private String companyDescription;
    public String getCompanyName() {
        return companyName;
    }
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    public String getCompanyURL() {
        return companyURL;
    }
    public void setCompanyURL(String companyURL) {
        this.companyURL = companyURL;
    }
    public String getCompanyDescription() {
        return companyDescription;
    }
    public void setCompanyDescription(String companyDescription) {
        this.companyDescription = companyDescription;
    }
}
